"""
app/api/v1/router.py
====================
Top-level API v1 router aggregator.

All module routers are registered here and mounted under /api/v1 in main.py.
Add new module routers to this file as they are created.

Phase 3 addition
----------------
    The ``endpoints.inventory`` router provides the Multi-Tenant Handloom
    Inventory Control Ledger Pipelines Engine surface — three async endpoints
    purpose-built for saree inventory ingestion, tenancy-scoped catalog
    listing, and advanced JSONB attribute filtering.
"""

from fastapi import APIRouter

from app.api.v1 import inventory
from app.api.v1.endpoints import inventory as handloom_inventory

api_router = APIRouter()

# ---------------------------------------------------------------------------
# Phase 1/2 — General ERP inventory module — /api/v1/inventory
# ---------------------------------------------------------------------------
api_router.include_router(
    inventory.router,
    prefix="/inventory",
    tags=["Inventory"],
)

# ---------------------------------------------------------------------------
# Phase 3 — Multi-Tenant Handloom Inventory Control Ledger Pipelines Engine
#            Mounted under /api/v1/inventory/saree to avoid route collision
#            with the general CRUD router above.  Specialised saree domain
#            endpoints:
#              POST   /api/v1/inventory/saree/              — ingest node
#              GET    /api/v1/inventory/saree/              — catalog listing
#              GET    /api/v1/inventory/saree/filter-attributes/ — JSONB filter
# ---------------------------------------------------------------------------
api_router.include_router(
    handloom_inventory.router,
    prefix="/inventory/saree",
    tags=["Multi-Tenant Handloom Inventory Control Ledger Pipelines Engine"],
)

# Future module routers (uncomment as created):
# from app.api.v1 import tenants, users, auth, reports
from app.api.v1.endpoints import billing
# api_router.include_router(auth.router,     prefix="/auth",     tags=["Auth"])
# api_router.include_router(tenants.router,  prefix="/tenants",  tags=["Tenants"])
# api_router.include_router(users.router,    prefix="/users",    tags=["Users"])
# api_router.include_router(reports.router,  prefix="/reports",  tags=["Reports"])

# ---------------------------------------------------------------------------
# Phase 8 — Module 3 Omnichannel Billing & Invoice Engine
# ---------------------------------------------------------------------------
api_router.include_router(
    billing.router,
    prefix="/billing",
    tags=["Billing"],
)

# ---------------------------------------------------------------------------
# Phase 8 — Module 4 AI Copilot Ledger & Finance Engine
# ---------------------------------------------------------------------------
from app.api.v1.endpoints import finance

api_router.include_router(
    finance.router,
    prefix="/finance",
    tags=["Finance"],
)

# ---------------------------------------------------------------------------
# Phase 8 — Module 5 Enterprise Data Migration Hub
# ---------------------------------------------------------------------------
from app.api.v1.endpoints import migration

api_router.include_router(
    migration.router,
    prefix="/migration",
    tags=["Migration"],
)
