"""
app/api/v1/endpoints/migration.py
=================================
Asynchronous endpoint router layer for the Enterprise Data Migration Hub.
"""

from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import IntegrityError
import structlog

from app.core.database import get_db
from app.models.migration import TenantDataMigrationLog, MigrationStatus
from app.schemas.migration import DataMigrationLogResponse


log = structlog.get_logger(__name__)
router = APIRouter()


@router.post(
    "/import",
    response_model=DataMigrationLogResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Trigger bulk data import",
)
async def trigger_bulk_import(
    request: Request,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
) -> TenantDataMigrationLog:
    """
    Accepts multi-part file payloads, maps tenant bounds context parsing filters 
    from active multi-tenant validation header chains, updates log states, 
    and appends records directly.
    """
    tenant_id = getattr(request.state, "tenant_id", None)
    if not tenant_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing tenant context. Ensure request passes through TenantAuthMiddleware.",
        )

    # 1. Validate file metadata
    if not file.filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No filename provided in upload.",
        )
        
    allowed_extensions = (".csv", ".xls", ".xlsx")
    if not file.filename.lower().endswith(allowed_extensions):
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail=f"Unsupported file format. Please upload {', '.join(allowed_extensions)}",
        )

    # 2. Initialize Migration Log
    db_log = TenantDataMigrationLog(
        tenant_id=tenant_id,
        source_file_name=file.filename,
        row_count_processed=0,
        migration_status=MigrationStatus.INITIALIZED,
    )
    
    db.add(db_log)
    try:
        await db.commit()
        await db.refresh(db_log)
        log.info(
            "migration_job_initialized", 
            file=file.filename, 
            tenant_id=str(tenant_id),
            log_id=str(db_log.id)
        )
        
        # NOTE: Actual file parsing (reading stream, converting to DB models, handling row inserts)
        # would typically be dispatched to an async worker (like Celery/ArQ) here to prevent 
        # blocking the HTTP response thread on large files. The background worker updates this 
        # log table to IN_PROGRESS -> SUCCESS/FAILED.
        
        return db_log
        
    except IntegrityError as e:
        await db.rollback()
        log.error("migration_initialization_failed", error=str(e), tenant_id=str(tenant_id))
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Database integrity failure while committing migration log.",
        )
