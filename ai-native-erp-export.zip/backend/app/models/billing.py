"""
app/models/billing.py
======================
SQLAlchemy 2.0 async ORM model for the Omnichannel Billing & Invoice Engine.

Module:   Module 3 — Omnichannel Billing & Invoice Engine
Table:    public.tenant_billing_invoices
Version:  1.0.0

Architecture
------------
  • Fully multi-tenant: every row is scoped to a ``tenant_id`` UUID that
    references ``public.tenants.id`` with ``ON DELETE CASCADE``.  No invoice
    can ever be read, written, or mutated by a query that does not include the
    correct tenant predicate.

  • Invoice line-item data is stored in an ``items_snapshot`` JSONB column —
    an immutable array of line-item records captured at the point of invoicing.
    Immutable means that subsequent changes to the source inventory item
    (price edits, SKU renames) do not silently mutate historical invoice data.

  • Financial columns use ``Numeric(14, 4)`` — 4 decimal places to support
    currencies with sub-cent precision (JPY, KWD, BHD) and tax-inclusive
    rounding rules without silent precision loss.

  • Two enum-style string columns (``payment_status``, ``payment_mode``) use
    CHECK constraints via ``Enum`` type rather than a plain String so Postgres
    itself rejects invalid values at the storage layer.

  • Three indices are defined explicitly:
      1. ``ix_billing_invoices_tenant_id``      — BTree on tenant_id for
         all tenant-scoped list queries (primary row-level isolation guard).
      2. ``ix_billing_invoices_invoice_number`` — Unique BTree on
         invoice_number globally (billing reference must be universally unique).
      3. ``ix_billing_invoices_tenant_status``  — Composite BTree on
         (tenant_id, payment_status) for fast dashboard-level status
         aggregation queries without full table scans.

Relationships (future)
-----------------------
  • ``tenant`` → public.tenants (FK, cascade delete)
  • ``created_by`` → public.user_profiles (FK, SET NULL on delete)
  • ``updated_by`` → public.user_profiles (FK, SET NULL on delete)

Migration note
--------------
  Generate the corresponding Alembic migration after adding this model:

      alembic revision --autogenerate -m "add_billing_invoices_table"
      alembic upgrade head
"""

from __future__ import annotations

import enum
import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.sql import func

from app.core.database import Base


# =============================================================================
# 1.  Enum literals — mirrors the Pydantic schema and Postgres CHECK constraint
# =============================================================================

class PaymentStatus(str, enum.Enum):
    """
    Lifecycle states of an invoice's payment.

    ``PENDING``   — invoice issued but payment not yet received.
    ``PAID``      — payment confirmed and settled.
    ``OVERDUE``   — payment not received past the due date.
    ``CANCELLED`` — invoice voided; no payment expected.
    ``FAILED``    — a payment attempt was made but rejected / reversed.
    ``REFUNDED``  — payment received but subsequently refunded in full.
    ``PARTIAL``   — partial payment received; remainder still outstanding.
    """
    PENDING   = "PENDING"
    PAID      = "PAID"
    OVERDUE   = "OVERDUE"
    CANCELLED = "CANCELLED"
    FAILED    = "FAILED"
    REFUNDED  = "REFUNDED"
    PARTIAL   = "PARTIAL"


class PaymentMode(str, enum.Enum):
    """
    Channel through which payment was (or will be) collected.

    ``UPI``       — Unified Payments Interface (India-specific real-time rail).
    ``CASH``      — physical cash payment at point-of-sale.
    ``CARD``      — debit or credit card (POS terminal or card-on-file).
    ``ONLINE``    — net-banking / payment gateway (Razorpay, Stripe, etc.).
    ``CHEQUE``    — paper cheque or demand draft.
    ``BANK_TRANSFER`` — NEFT / RTGS / SWIFT wire transfer.
    ``WALLET``    — digital wallet (Paytm, PhonePe, Google Pay, etc.).
    ``EMI``       — equated monthly instalment via bank or NBFC.
    ``CREDIT``    — internal credit note applied against invoice.
    ``OTHER``     — any channel not covered by the above cases.
    """
    UPI           = "UPI"
    CASH          = "CASH"
    CARD          = "CARD"
    ONLINE        = "ONLINE"
    CHEQUE        = "CHEQUE"
    BANK_TRANSFER = "BANK_TRANSFER"
    WALLET        = "WALLET"
    EMI           = "EMI"
    CREDIT        = "CREDIT"
    OTHER         = "OTHER"


# =============================================================================
# 2.  ORM Model
# =============================================================================

class TenantBillingInvoice(Base):
    """
    ORM model for ``public.tenant_billing_invoices``.

    Represents a single tax invoice issued by a tenant to a buyer.
    Each invoice:
      • Belongs exclusively to one tenant (row-level isolation via tenant_id).
      • Carries an immutable snapshot of the line items at the time of issuance.
      • Tracks the full payment lifecycle from PENDING through PAID / FAILED.
      • Supports all major Indian and global payment rails via PaymentMode.

    ``items_snapshot`` schema (JSONB array of objects)
    --------------------------------------------------
    Each element in the array represents one invoice line item::

        {
            "sku":          "KNJ-RED-001",
            "name":         "Kanjivaram Red Silk",
            "quantity":     2,
            "unit_price":   4999.00,
            "line_total":   9998.00,
            "currency":     "INR",
            "tax_rate_pct": 5.0,
            "tax_amount":   499.90,
            "discount_pct": 0.0,
            "attributes":   { ... }    // optional item attribute snapshot
        }

    Keeping this as an immutable snapshot (not a FK join to inventory_items)
    means invoice history is never corrupted by subsequent product edits.
    """

    __tablename__ = "tenant_billing_invoices"

    # ── Table-level constraints and indices ────────────────────────────────────
    __table_args__ = (
        # Unique: invoice_number must be globally unique (across all tenants).
        # Serves as the human-readable billing reference (e.g. "INV-2024-00412").
        UniqueConstraint(
            "invoice_number",
            name="uq_billing_invoices_invoice_number",
        ),

        # Composite index: tenant_id + payment_status speeds up dashboard
        # queries like "show me all PENDING invoices for tenant X" without
        # performing a full table scan.
        Index(
            "ix_billing_invoices_tenant_status",
            "tenant_id",
            "payment_status",
        ),

        # Composite index: tenant_id + created_at for chronological listing
        # queries (GET /billing/invoices?limit=20&offset=0 ordered by date).
        Index(
            "ix_billing_invoices_tenant_created",
            "tenant_id",
            "created_at",
        ),

        # CHECK: total_amount must equal subtotal + tax_amount.
        # Postgres enforces this at the storage layer — no app-layer bugs
        # can produce an invoice where the numbers don't add up.
        CheckConstraint(
            "total_amount = subtotal + tax_amount",
            name="ck_billing_invoices_total_equals_subtotal_plus_tax",
        ),

        # CHECK: all monetary amounts must be non-negative.
        CheckConstraint(
            "subtotal >= 0 AND tax_amount >= 0 AND total_amount >= 0",
            name="ck_billing_invoices_amounts_non_negative",
        ),

        {"schema": "public"},
    )

    # ── Primary Key ────────────────────────────────────────────────────────────

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default=text("uuid_generate_v4()"),
        comment="Immutable row UUID — primary key.",
    )

    # ── Multi-Tenant Isolation ─────────────────────────────────────────────────

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "public.tenants.id",
            ondelete="CASCADE",    # deleting the tenant purges all its invoices
            name="fk_billing_invoices_tenant_id",
        ),
        nullable=False,
        index=True,                # ix_billing_invoices_tenant_id (auto-named)
        comment=(
            "UUID of the owning tenant. "
            "All queries MUST filter on this column for row-level isolation."
        ),
    )

    # ── Invoice Identity ───────────────────────────────────────────────────────

    invoice_number: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        # UniqueConstraint declared in __table_args__ gives a named constraint;
        # `unique=True` here also creates an index on this single column for
        # direct lookup queries (GET /billing/invoices/{invoice_number}).
        unique=True,
        comment=(
            "Human-readable billing reference. Must be globally unique. "
            "Suggested format: INV-{YYYY}-{NNNNN} (e.g. INV-2024-00412). "
            "Generated by the application layer before insert."
        ),
    )

    # ── Buyer / Customer Reference ─────────────────────────────────────────────

    customer_name: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
        comment="Display name of the buyer — stored as plain text for portability.",
    )

    customer_email: Mapped[str | None] = mapped_column(
        String(320),       # RFC 5321 max email length
        nullable=True,
        comment="Buyer e-mail address for invoice delivery.",
    )

    customer_phone: Mapped[str | None] = mapped_column(
        String(32),
        nullable=True,
        comment="Buyer contact number (E.164 format preferred, e.g. +919876543210).",
    )

    customer_gstin: Mapped[str | None] = mapped_column(
        String(15),        # Indian GST registration number length
        nullable=True,
        comment="Buyer GSTIN (Goods & Services Tax Identification Number) for B2B invoices.",
    )

    billing_address: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Full billing address stored as plain text for immutability.",
    )

    # ── Financial Amounts ──────────────────────────────────────────────────────
    #
    # Numeric(10, 2): 10 total digits, 2 after the decimal point.
    # Supports amounts up to ₹99,999,999.99.

    currency: Mapped[str] = mapped_column(
        String(3),
        nullable=False,
        server_default=text("'INR'"),
        comment="ISO 4217 three-letter currency code (e.g. INR, USD, EUR).",
    )

    subtotal: Mapped[float] = mapped_column(
        Numeric(10, 2),
        nullable=False,
        server_default=text("0"),
        comment="Sum of all line-item totals before tax.",
    )

    tax_amount: Mapped[float] = mapped_column(
        Numeric(10, 2),
        nullable=False,
        server_default=text("0"),
        comment=(
            "Total tax (GST, VAT, sales tax) levied on the invoice. "
            "Stored separately for tax-authority reporting."
        ),
    )

    total_amount: Mapped[float] = mapped_column(
        Numeric(10, 2),
        nullable=False,
        server_default=text("0"),
        comment=(
            "Final amount payable (subtotal + tax_amount). "
            "Enforced by CHECK constraint: total_amount = subtotal + tax_amount."
        ),
    )

    discount_amount: Mapped[float] = mapped_column(
        Numeric(10, 2),
        nullable=False,
        server_default=text("0"),
        comment=(
            "Total discount applied across all line items (informational). "
            "Already deducted from subtotal — not subtracted again from total."
        ),
    )

    # ── Tax Reference Fields ───────────────────────────────────────────────────

    tax_rate_pct: Mapped[float | None] = mapped_column(
        Numeric(6, 4),
        nullable=True,
        comment=(
            "Blended effective tax rate as a percentage (e.g. 18.0000 for 18 % GST). "
            "Informational; line-level rates are stored in items_snapshot."
        ),
    )

    gstin_seller: Mapped[str | None] = mapped_column(
        String(15),
        nullable=True,
        comment="Seller (tenant) GSTIN for GST-compliant invoice generation.",
    )

    # ── Payment Lifecycle ──────────────────────────────────────────────────────

    payment_status: Mapped[str] = mapped_column(
        Enum(
            PaymentStatus,
            name="billing_payment_status",
            create_type=True,
            schema="public",
        ),
        nullable=False,
        server_default=text("'PENDING'"),
        comment=(
            "Current payment lifecycle state. "
            "Valid values: PENDING | PAID | OVERDUE | CANCELLED | FAILED | REFUNDED | PARTIAL."
        ),
    )

    payment_mode: Mapped[str | None] = mapped_column(
        Enum(
            PaymentMode,
            name="billing_payment_mode",
            create_type=True,
            schema="public",
        ),
        nullable=True,
        comment=(
            "Channel used for payment. Null until payment is recorded. "
            "Valid values: UPI | CASH | CARD | ONLINE | CHEQUE | BANK_TRANSFER | "
            "WALLET | EMI | CREDIT | OTHER."
        ),
    )

    payment_reference: Mapped[str | None] = mapped_column(
        String(128),
        nullable=True,
        comment=(
            "External transaction / UTR reference from the payment gateway. "
            "Populated on payment confirmation (e.g. UPI transaction ID, "
            "Razorpay payment_id, bank UTR number)."
        ),
    )

    paid_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timestamp of payment confirmation. Null until payment is received.",
    )

    due_date: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment=(
            "Payment due date. Used by the overdue-detection cron job to "
            "transition invoices from PENDING → OVERDUE."
        ),
    )

    # ── Items Snapshot — Immutable JSONB Array ─────────────────────────────────

    items_snapshot: Mapped[list[dict[str, Any]]] = mapped_column(
        JSONB,
        nullable=False,
        server_default=text("'[]'::jsonb"),
        comment=(
            "Immutable array of invoice line-item records captured at issuance time. "
            "Each element contains: sku, name, quantity, unit_price, line_total, "
            "currency, tax_rate_pct, tax_amount, discount_pct, and an optional "
            "attributes snapshot from the inventory item. "
            "Stored as JSONB for Postgres GIN indexing and -> / ->> operator queries. "
            "NEVER mutated after invoice creation — historical accuracy is paramount."
        ),
    )

    # ── Supplementary Metadata ─────────────────────────────────────────────────

    notes: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Free-text internal notes or buyer-facing invoice remarks.",
    )

    invoice_metadata: Mapped[dict[str, Any] | None] = mapped_column(
        JSONB,
        nullable=True,
        server_default=text("'{}'::jsonb"),
        comment=(
            "Extensible key-value metadata for integration-specific data "
            "(e.g. accounting system reference, POS terminal ID, channel tag). "
            "Not used for business logic."
        ),
    )

    # ── Soft Delete & Versioning ───────────────────────────────────────────────

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        server_default=text("TRUE"),
        comment=(
            "Soft-delete flag. False = invoice is voided / cancelled. "
            "Voided invoices are excluded from all aggregate queries. "
            "Physical deletion is never performed (audit trail preservation)."
        ),
    )

    invoice_version: Mapped[int] = mapped_column(
        # Using text("1") instead of Integer default so Alembic generates
        # the correct server-default SQL rather than a Python-side default.
        Numeric(6, 0),
        nullable=False,
        server_default=text("1"),
        comment=(
            "Optimistic-locking version counter. Incremented on each amendment. "
            "Version 1 = original issue; version 2+ = amended invoice."
        ),
    )

    # ── Audit Trail ───────────────────────────────────────────────────────────

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "public.user_profiles.id",
            ondelete="SET NULL",
            name="fk_billing_invoices_created_by",
        ),
        nullable=True,
        comment="UUID of the user who created / issued the invoice.",
    )

    updated_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "public.user_profiles.id",
            ondelete="SET NULL",
            name="fk_billing_invoices_updated_by",
        ),
        nullable=True,
        comment="UUID of the user who last modified the invoice record.",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        comment="UTC timestamp of row creation (invoice issuance datetime).",
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        onupdate=func.now(),
        comment="UTC timestamp of last row modification (auto-updated by SQLAlchemy).",
    )

    # ── Repr ───────────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return (
            f"<TenantBillingInvoice "
            f"invoice_number={self.invoice_number!r} "
            f"tenant={self.tenant_id} "
            f"status={self.payment_status} "
            f"total={self.total_amount}>"
        )
