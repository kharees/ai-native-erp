"""
app/models/inventory.py
=======================
SQLAlchemy 2.0 async ORM model for the public.inventory_items table.

This model mirrors the DDL defined in migrations/V001__initial_schema.sql
exactly — column types, constraints, and defaults are kept in sync.
The `attributes` column is mapped to a JSONB column so SQLAlchemy
serialises / deserialises Python dicts transparently.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    String,
    Text,
    text,
)
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from app.core.database import Base


class InventoryItem(Base):
    """
    ORM model for public.inventory_items.

    Multi-tenant inventory item with a flexible JSONB `attributes` matrix
    that stores schema-less product properties per industry template
    (Manufacturing | Retail | Services).
    """

    __tablename__  = "inventory_items"
    __table_args__ = {"schema": "public"}

    # -------------------------------------------------------------------------
    # Identity
    # -------------------------------------------------------------------------
    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default=text("uuid_generate_v4()"),
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("public.tenants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    sku:         Mapped[str]        = mapped_column(String(64),  nullable=False)
    name:        Mapped[str]        = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)

    # -------------------------------------------------------------------------
    # Categorisation
    # -------------------------------------------------------------------------
    category:     Mapped[str | None] = mapped_column(String(128))
    sub_category: Mapped[str | None] = mapped_column(String(128))
    brand:        Mapped[str | None] = mapped_column(String(128))
    tags:         Mapped[list[str]]  = mapped_column(
        ARRAY(Text),
        nullable=False,
        server_default=text("'{}'::text[]"),
    )

    # -------------------------------------------------------------------------
    # Pricing & stock
    # -------------------------------------------------------------------------
    unit_price:       Mapped[float] = mapped_column(Numeric(18, 4), nullable=False, server_default=text("0"))
    cost_price:       Mapped[float] = mapped_column(Numeric(18, 4), nullable=False, server_default=text("0"))
    currency:         Mapped[str]   = mapped_column(String(3),  nullable=False, server_default=text("'USD'"))
    quantity_on_hand: Mapped[int]   = mapped_column(Integer,    nullable=False, server_default=text("0"))
    reorder_level:    Mapped[int]   = mapped_column(Integer,    nullable=False, server_default=text("0"))
    unit_of_measure:  Mapped[str]   = mapped_column(String(32), nullable=False, server_default=text("'unit'"))

    # -------------------------------------------------------------------------
    # JSONB attribute matrix  — discriminated by attributes["template"]
    # -------------------------------------------------------------------------
    attributes: Mapped[dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        server_default=text("'{}'::jsonb"),
    )

    # -------------------------------------------------------------------------
    # Status & lifecycle
    # -------------------------------------------------------------------------
    status:    Mapped[str]  = mapped_column(String(32),  nullable=False, server_default=text("'draft'"))
    is_active: Mapped[bool] = mapped_column(Boolean,     nullable=False, server_default=text("TRUE"))

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("public.user_profiles.id", ondelete="SET NULL"),
        nullable=True,
    )
    updated_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("public.user_profiles.id", ondelete="SET NULL"),
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        onupdate=func.now(),
    )

    def __repr__(self) -> str:
        return f"<InventoryItem sku={self.sku!r} tenant={self.tenant_id}>"
