"""
app/models/migration.py
========================
SQLAlchemy 2.0 async ORM model for the Enterprise Data Migration Hub.

Module:   Module 5 — Enterprise Data Migration Hub
Table:    public.tenant_data_migration_logs
Version:  1.0.0

Architecture
------------
  • Fully multi-tenant: row-level isolation enforced via ``tenant_id``.
  • Migration Logs: Tracks the processing state of large batch data imports 
    (e.g., CSV/Excel inventory or finance dumps) uploaded by users.
  • Error Handling: ``error_log_dump`` safely catches parsing glitches dynamically.
"""

from __future__ import annotations

import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    text,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.sql import func

from app.core.database import Base


# =============================================================================
# 1.  Enums
# =============================================================================

class MigrationStatus(str, enum.Enum):
    """
    Lifecycle state of a data migration batch job.
    """
    INITIALIZED = "INITIALIZED"
    IN_PROGRESS = "IN_PROGRESS"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"


# =============================================================================
# 2.  ORM Model
# =============================================================================

class TenantDataMigrationLog(Base):
    """
    ORM model for ``public.tenant_data_migration_logs``.

    Tracks and logs the execution progress of Enterprise batch data imports.
    """

    __tablename__ = "tenant_data_migration_logs"

    __table_args__ = (
        # Composite index for fast querying of migration jobs by status per tenant
        Index(
            "ix_tenant_migration_logs_status",
            "tenant_id",
            "migration_status",
        ),
        {"schema": "public"},
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default=text("uuid_generate_v4()"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("public.tenants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    source_file_name: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        comment="Name of the uploaded source file (e.g., legacy_inventory_2024.csv)",
    )

    row_count_processed: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        server_default=text("0"),
        comment="Number of rows successfully ingested during this migration run",
    )

    migration_status: Mapped[str] = mapped_column(
        Enum(
            MigrationStatus,
            name="migration_job_status",
            create_type=True,
            schema="public",
        ),
        nullable=False,
        server_default=text("'INITIALIZED'"),
    )

    error_log_dump: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Detailed JSON or Text stacktrace catching structural schema parsing glitches dynamically.",
    )

    # ── Standard Audit & Versioning ────────────────────────────────────────────

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        server_default=text("TRUE"),
    )

    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("public.user_profiles.id", ondelete="SET NULL"),
        nullable=True,
    )
    
    updated_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("public.user_profiles.id", ondelete="SET NULL"),
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )
    
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        onupdate=func.now(),
    )

    def __repr__(self) -> str:
        return (
            f"<TenantDataMigrationLog file={self.source_file_name} "
            f"status={self.migration_status} rows={self.row_count_processed}>"
        )
